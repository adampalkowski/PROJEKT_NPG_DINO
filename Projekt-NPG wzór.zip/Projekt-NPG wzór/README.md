# Projekt-NPG

Projekt z Narzędzi Pracy Grupowej 2022

Grupa:
Krzysztof Furtak
Filip Dymczyk
Konrad Grucel
Klaudiusz Grobelski
Łukasz Filo